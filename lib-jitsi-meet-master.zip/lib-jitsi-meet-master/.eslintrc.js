module.exports = {
    parserOptions: {
        requireConfigFile: false
    },
    'extends': [
        '@jitsi/eslint-config'
    ]
};
