import BrowserCapabilities from './BrowserCapabilities';

export default new BrowserCapabilities();
