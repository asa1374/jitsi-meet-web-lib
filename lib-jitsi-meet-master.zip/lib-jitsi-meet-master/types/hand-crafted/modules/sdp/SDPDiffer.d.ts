export default function SDPDiffer( mySDP: unknown, otherSDP: unknown ): void;

export default class SDPDiffer {
  constructor( mySDP: unknown, otherSDP: unknown ); // TODO:
  getNewMedia: () => unknown; // TODO:
  toJingle: ( modify: unknown ) => unknown; // TODO:
}
