export class PerformanceObserverStats {
  constructor( emitter: unknown, statsInterval: unknown ); // TODO:
  getLongTasksStats: () => unknown; // TODO:
  startObserver: () => void;
  stopObserver: () => void;
}
