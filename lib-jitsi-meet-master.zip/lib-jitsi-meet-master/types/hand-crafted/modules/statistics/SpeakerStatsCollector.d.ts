import JitsiConference from '../../JitsiConference';

export default class SpeakerStatsCollector {
  constructor( conference: JitsiConference );
  getStats: () => unknown; // TODO:
}
