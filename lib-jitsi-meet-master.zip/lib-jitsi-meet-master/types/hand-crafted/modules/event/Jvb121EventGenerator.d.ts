import JitsiConference from '../../JitsiConference';

export default class Jvb121EventGenerator {
  constructor( conference: JitsiConference );
  evaluateStatus: () => void;
}
