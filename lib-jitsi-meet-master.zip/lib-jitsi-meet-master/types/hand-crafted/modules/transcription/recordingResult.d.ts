export default class RecordingResult {
  constructor( blob: unknown, name: unknown, startTime: unknown, wordArray: unknown ); // TODO:
  readonly blob: unknown; // TODO:
  readonly name: unknown; // TODO:
  readonly startTime: unknown; // TODO:
  readonly wordArray: unknown; // TODO:
}
