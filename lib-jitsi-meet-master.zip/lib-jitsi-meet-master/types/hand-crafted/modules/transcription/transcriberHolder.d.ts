export type transcriberHolder = {
  transcribers: unknown[], // TODO
  add: ( transcriber: unknown ) => void; // TODO:
}
