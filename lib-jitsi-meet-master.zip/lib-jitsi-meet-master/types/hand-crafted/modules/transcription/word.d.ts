export default class Word {
  word: string;
  begin: number;
  end: number;
  getWord: () => string;
  getBeginTime: () => number;
  getEndTime: () => number;
}
