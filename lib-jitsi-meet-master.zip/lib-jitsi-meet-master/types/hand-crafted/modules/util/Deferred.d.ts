export default class Deferred {
  constructor();
  clearRejectTimeout: () => void;
  setRejectTimeout: ( ms: number ) => void;
}
