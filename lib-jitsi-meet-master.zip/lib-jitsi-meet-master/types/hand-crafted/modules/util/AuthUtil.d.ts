export function getTokenAuthUrl( urlPattern: string, roomName: string, roleUpgrade: boolean ): string;
