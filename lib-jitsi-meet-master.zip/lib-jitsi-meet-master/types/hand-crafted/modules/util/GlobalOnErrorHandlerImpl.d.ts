export function addHandler( handler: unknown ): void;

export function callErrorHandler( error: Error ): void;

export function callUnhandledRejectionHandler( error: Error ): void;
