export function integerHash( string: string ): number;
