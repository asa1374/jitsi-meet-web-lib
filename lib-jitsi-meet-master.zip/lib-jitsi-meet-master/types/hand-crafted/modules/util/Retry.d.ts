export function getJitterDelay( retry: number, minDelay?: number, base?: number ): number;
