declare const nextTick: ( advanceTimer?: number ) => Promise<void>;
