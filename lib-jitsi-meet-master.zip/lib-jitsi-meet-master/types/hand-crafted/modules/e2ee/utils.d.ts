export function polyFillEncodedFrameMetadata( encodedFrame: RTCEncodedAudioFrame | RTCEncodedVideoFrame, controller: unknown ): void; // TODO:

export function isArrayEqual<T>( a1: Array<T>, a2: Array<T> ): boolean;

