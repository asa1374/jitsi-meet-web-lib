import JitsiConference from '../../JitsiConference';

export default class P2PDominantSpeakerDetection {
  constructor( conference: JitsiConference );
}
