import JitsiConference from '../../JitsiConference';
import EventEmitter from '../../EventEmitter';

export default class NoAudioSignalDetection extends EventEmitter<unknown> { // TODO:
  constructor( conference: JitsiConference ); // TODO
}
