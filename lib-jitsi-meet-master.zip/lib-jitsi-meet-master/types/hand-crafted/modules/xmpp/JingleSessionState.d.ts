export enum JingleSessionState {
  PENDING = 'pending',
  ACTIVE = 'active',
  ENDED = 'ended'
}
