export enum AuthenticationEvents {
  IDENTITY_UPDATED = 'authentication.identity_updated'
}
