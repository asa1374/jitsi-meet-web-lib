export enum VideoType {
  CAMERA = 'camera',
  DESKTOP = 'desktop',
}
