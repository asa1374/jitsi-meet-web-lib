export enum BridgeVideoType {
  CAMERA = 'camera',
  DESKTOP = 'desktop',
  DESKTOP_HIGH_FPS = 'desktop_high_fps',
  NONE = 'none',
}
