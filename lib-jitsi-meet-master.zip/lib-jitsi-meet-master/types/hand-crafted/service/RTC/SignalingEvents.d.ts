export enum SignallingEvents {
  PEER_MUTED_CHANGED = 'signaling.peerMuted',
  PEER_VIDEO_TYPE_CHANGED = 'signaling.peerVideoType'
}
