export enum CodecMimeType {
  H264 = 'h264',
  OPUS = 'opus',
  VP8 = 'vp8',
  VP9 = 'vp9'
}
