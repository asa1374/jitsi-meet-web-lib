export enum MediaType {
  AUDIO = 'audio',
  VIDEO = 'video'
}
