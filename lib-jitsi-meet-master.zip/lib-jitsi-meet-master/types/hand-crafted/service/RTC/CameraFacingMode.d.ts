export enum CameraFacingMode {
  ENVIRONMENT = 'environment',
  USER = 'user'
}
