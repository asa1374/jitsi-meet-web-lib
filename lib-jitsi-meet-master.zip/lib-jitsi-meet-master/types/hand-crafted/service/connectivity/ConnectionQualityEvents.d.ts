export enum ConnectionQualityEvents {
  LOCAL_STATS_UPDATED = 'cq.local_stats_updated',
  REMOTE_STATS_UPDATED = 'cq.remote_stats_updated'
}
