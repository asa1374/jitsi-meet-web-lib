export enum E2ePingEvents {
  E2E_RTT_CHANGED = 'e2eping.e2e_rtt_changed'
}
