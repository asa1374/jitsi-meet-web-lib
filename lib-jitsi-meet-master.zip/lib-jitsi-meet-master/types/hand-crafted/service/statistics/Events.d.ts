declare enum Events {
  AUDIO_LEVEL = 'statistics.audioLevel',
  BEFORE_DISPOSED = 'statistics.before_disposed',
  BYTE_SENT_STATS = 'statistics.byte_sent_stats',
  CONNECTION_STATS = 'statistics.connectionstats',
  LONG_TASKS_STATS = 'statistics.long_tasks_stats'
}
