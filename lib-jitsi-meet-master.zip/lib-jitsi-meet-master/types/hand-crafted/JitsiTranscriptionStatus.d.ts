export enum JitsiTranscriptionStatus {
  ON = 'ON',
  OFF = 'OFF'
}
