export const LOCAL_JID = 'local'
