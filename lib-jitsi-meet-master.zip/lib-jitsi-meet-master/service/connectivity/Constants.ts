// Number of times the client attempts to reconnect to the XMPP server or JVB (in case of an ICE failure).
export const MAX_CONNECTION_RETRIES = 3;
