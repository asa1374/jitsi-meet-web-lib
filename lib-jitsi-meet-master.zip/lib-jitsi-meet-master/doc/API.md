Jitsi Meet API
============

This document has been moved here: https://jitsi.github.io/handbook/docs/dev-guide/dev-guide-ljm-api
