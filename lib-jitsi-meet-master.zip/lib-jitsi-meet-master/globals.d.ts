export {};

declare global {
    interface Window {
        connectionTimes: any;
    }
}
